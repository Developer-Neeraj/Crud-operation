<?php 
    // $conn = mysqli_connect('localhost', 'root', '', 'crud') or die('Connection Failed');
    $conn = mysqli_connect('sql210.epizy.com', 'epiz_26895254', '', 'epiz_26895254_crud') or die('Connection Failed');
?>